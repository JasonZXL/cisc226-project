using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playermovement : MonoBehaviour
{
    //两个玩家初始值，生命值和飞行速度
    [SerializeField] private float movementSpeed = 1f;
    [SerializeField] private int Health = 2;

    //不用管
    private Rigidbody2D rb;
    private Vector2 movementDirection;

    //玩家武器等级
    public int weapon_level = 1;
    
    //武器等级 = 2的射击方案
    private Vector3[] TwoFX = {new Vector3(0,0,-15), new Vector3(0,0,15)};
    //控制玩家射击间隔的参数
    private float nextFire = 0.5f;
    private GameObject newbulletPrefab;
    private float myTime = 0.2f;
    private float fireDelta = 0.5f;
    
    //不用管
    public Transform shooting_postion;
    public GameObject bulletPrefab;
    

    //24 - 33是用于开始游戏载入初始加成道具的
    public Transform bullet_boost_position;
    public Transform Health_boost_position;
    public Transform Speed_boost_position;
    public GameObject Bullet_boost;
    public GameObject Speed_boost;
    public GameObject Health_boost;
    private GameObject newHealth_boostPrefab;
    private GameObject newSpeed_boostPrefab;
    private GameObject newbullet_boostPrefab;

 
    //有关飞机本体碰撞的逻辑
    private void OnTriggerEnter2D(Collider2D collision){
        //如果碰到敌机1
        if(collision.tag == "enemy1"){
            Destroy(collision.gameObject);
            Health = Health -2;
        }
        //如果碰到敌机1的子弹
        else if(collision.tag == "enemy1_bullet"){
            Destroy(collision.gameObject);
            Health --;
        }
        //如果碰到health boost
        else if(collision.tag == "Health_boost"){
            Destroy(collision.gameObject);
            Health = Health + 2;
        }
        //如果碰到speed boost
        else if(collision.tag == "Speed_boost"){
            Destroy(collision.gameObject);
            movementSpeed ++;
        
            
        }
        //如果碰到bullet boost
        else if(collision.tag == "Bullet_boost"){
            Destroy(collision.gameObject);
            weapon_level ++;
        }
    }

     void Start()
    {
        float boost = Random.Range(0, 3);
        if(boost == 1){
            newSpeed_boostPrefab = Instantiate(Speed_boost,Speed_boost_position.position, Speed_boost_position.rotation) as GameObject;
        }
        else if(boost == 2){
             newbullet_boostPrefab = Instantiate(Bullet_boost,bullet_boost_position.position, bullet_boost_position.rotation) as GameObject;
        }
        else if(boost == 0){
             newHealth_boostPrefab = Instantiate(Health_boost,Health_boost_position.position, Health_boost_position.rotation) as GameObject;
        }
       
       
        rb = GetComponent<Rigidbody2D>();
    }
   
    void LateUpdate(){
        if(Health ==0){
            Destroy(gameObject);
        }
    }
 
    void Update()
    {
        myTime = myTime + Time.deltaTime;

        if (Input.GetButton("Fire1") && myTime > nextFire) 
        {   //如果武器等级为1
            if(weapon_level == 1){
                nextFire = myTime + fireDelta;
                newbulletPrefab = Instantiate(bulletPrefab, new Vector3(transform.position.x, transform.position.y+1, transform.position.z), Quaternion.Euler(0,0,0));
                nextFire = nextFire - myTime;
                myTime = 0.2f;
            }
            //如果武器等级为2
            else if(weapon_level == 2){
                nextFire = myTime + fireDelta;
                for(int i=0;i<2;i++){
                    Instantiate(bulletPrefab, new Vector3(transform.position.x, transform.position.y+1, transform.position.z), Quaternion.Euler(TwoFX[i]));
                }
                nextFire = nextFire - myTime;
                myTime = 0.2f; 
            }
             
        }

        movementDirection = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        
        
    }


    void FixedUpdate(){
        rb.velocity = movementDirection * movementSpeed * 4;
    }

    
}
