using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyweapon : MonoBehaviour

{
    public Transform shooting_postion;
    public GameObject bulletPrefab;
    void Start()
    {
        float shoot = Random.Range(0, 10);
        if(shoot<=5){
            Instantiate(bulletPrefab, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.Euler(0,0,0));
        }
    }

    
}
