using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed;
  
    void Update()
    {
        transform.position += new Vector3(0, speed*Time.deltaTime*-1, 0);
        
        if(transform.position.y<-6){
            Destroy(gameObject);
        }
    }
    void OnTriggerEnter2D(Collider2D hitInfo){

        Destroy(gameObject);
    }
}
